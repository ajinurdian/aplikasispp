<?php include 'header.php'; ?>
	<div class="container">
		<div class="panel-body">
	<h2>SELAMAT DATANG</h2>
	<H5>SMK NEGERI 3 BANJAR</H5>
	<style >
    	body{
    		background:url('img/background1.jpg');
    		background-size: 400px;
    	}
    </style>
</div>
</div>